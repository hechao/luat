module(...,package.seeall)

sys.timer_loop_start(print,1000,"test version",_G.VERSION)
