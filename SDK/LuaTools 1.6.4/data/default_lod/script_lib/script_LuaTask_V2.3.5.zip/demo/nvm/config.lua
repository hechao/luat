module(...)

strPara = "str1"
numPara = 1
boolPara = false
tablePara = {"item1-1","item1-2","item1-3"}
