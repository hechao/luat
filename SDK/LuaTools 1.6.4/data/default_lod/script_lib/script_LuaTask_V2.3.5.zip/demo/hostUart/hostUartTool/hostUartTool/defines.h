
#ifndef __DEFINES_H__
#define __DEFINES_H__

#define MIN(A,B)            ((A) < (B) ? (A) : (B))
#define MAX(A,B)            ((A) > (B) ? (A) : (B))
#define ARRAY_SIZE(a)       (sizeof(a)/sizeof(a[0]))

#define PRODUCT_ID      11
#define _BASE_TITLE_ _T("M0С��д��վ����")

#endif

